import os
from panda import Panda

def test_recover():
  p = Panda()
  p.recover()

def test_flash():
  p = Panda()
  p.flash()

