#define uint8_t unsigned char
#define uint32_t unsigned int
#define int64_t long long
#define uint64_t unsigned long long
