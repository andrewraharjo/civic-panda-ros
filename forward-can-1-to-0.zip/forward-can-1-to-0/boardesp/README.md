
Dependencies
-----

**Mac**

```
./get_sdk.sh
```

**Debian / Ubuntu**

```
./get_sdk_mac.sh
```

Programming
-----

```
make
```
