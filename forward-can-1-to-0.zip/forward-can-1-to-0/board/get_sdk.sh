#!/bin/bash
sudo apt-get install gcc-arm-none-eabi python-pip
sudo pip2 install libusb1 pycrypto requests
