#pragma once
#include "stdafx.h"

extern HMODULE thisdll;
